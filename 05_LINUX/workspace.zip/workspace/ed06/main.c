#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//������ ���
	int i=2;
	int j=1;
	
	for(i=2;i<=9;i++){
		
		for(j=1;j<=9;j++){
			printf("%d*%d=%d\n",i,j,(i*j));
		}
		printf("\n");
		
	} 
	return 0;
}
