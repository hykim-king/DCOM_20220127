#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int i = 3;
	int j = 2;
	
	printf("%d+%d=%d\n",i,j,(i+j));
	printf("%d-%d=%d\n",i,j,(i-j));
	printf("%d*%d=%d\n",i,j,(i*j));
	printf("%d/%d=%1.1f\n",i,j,(i/(float)j));
	printf("%d%%d=%d\n",i,j,(i%j));
	return 0;
}
//3+2=5
//3-2=1
//3*2=6
//3/2=1.5
//3%d=2
