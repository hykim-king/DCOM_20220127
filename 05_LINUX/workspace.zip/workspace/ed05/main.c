#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i;
	int sum = 0;
	for(i=1;i<=10;i++){
		sum+=i;
		printf("i=%d \n",i);
	}
	printf("sum=%d\n",sum);
	return 0;
}
//i=1
//i=2
//i=3
//i=4
//i=5
//i=6
//i=7
//i=8
//i=9
//i=10
//sum=55
