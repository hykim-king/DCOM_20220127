col FILE_NAME        for a52
col BYTES            for 999999999.99
col BLOCKS           for 9999999
col STATUS           for a20
col AUTOEXTENSIBLE   for a20
col ONLINE_STATUS    for a20
col TABLESPACE_NAME   for a20

SELECT FILE_NAME, 
       BYTES, 
       BLOCKS, 
       STATUS ,
       AUTOEXTENSIBLE ,
       ONLINE_STATUS,
       TABLESPACE_NAME
FROM DBA_DATA_FILES
;

FILE_NAME                                                    BYTES   BLOCKS STATUS     AUTOEXTENSIBLE       ONLINE_STATUS        TABLESPACE_NAME
---------------------------------------------------- ------------- -------- ---------- -------------------- -------------------- --------------------
C:\APP\ITSC\PRODUCT\18.0.0\ORADATA\XE\SYSTEM01.DBF    880803840.00   107520 AVAILABLE  YES                  SYSTEM               SYSTEM
C:\APP\ITSC\PRODUCT\18.0.0\ORADATA\XE\SYSAUX01.DBF    597688320.00    72960 AVAILABLE  YES                  ONLINE               SYSAUX
C:\APP\ITSC\PRODUCT\18.0.0\ORADATA\XE\UNDOTBS01.DBF   351272960.00    42880 AVAILABLE  YES                  ONLINE               UNDOTBS1
C:\APP\ITSC\PRODUCT\18.0.0\ORADATA\XE\USERS01.DBF     262144000.00    32000 AVAILABLE  YES                  ONLINE               USERS
C:\APP\ITSC\PRODUCT\18.0.0\ORADATA\XE\JAMES.DBF       524288000.00    64000 AVAILABLE  YES                  ONLINE               JAMES_TS

��   ��: 00:00:00.01