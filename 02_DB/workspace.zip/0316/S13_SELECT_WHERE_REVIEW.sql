SELECT *
FROM emp
WHERE empno = 7782
;