SELECT SUBSTR(ename,3)
FROM emp
;