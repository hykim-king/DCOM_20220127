col USERNAME              for a25
col EXPIRY_DATE           for a16
col DEFAULT_TABLESPACE    for a20
col TEMPORARY_TABLESPACE  for a20
col PROFILE               for a20
col AUTHENTICATION_TYPE    for a20

SELECT USERNAME, 
       EXPIRY_DATE,
       DEFAULT_TABLESPACE,
       TEMPORARY_TABLESPACE,
       PROFILE,
       AUTHENTICATION_TYPE
FROM DBA_USERS
;

USERNAME                  EXPIRY_DATE      DEFAULT_TABLESPACE   TEMPORARY_TABLESPACE PROFILE              AUTHENTICATION_TYPE
------------------------- ---------------- -------------------- -------------------- -------------------- --------------------
SYS                       19/08/03         SYSTEM               TEMP                 DEFAULT              PASSWORD
SYSTEM                    22/09/10         SYSTEM               TEMP                 DEFAULT              PASSWORD
XS$NULL                   19/02/04         SYSTEM               TEMP                 DEFAULT              PASSWORD
OJVMSYS                                    SYSTEM               TEMP                 DEFAULT              NONE
LBACSYS                                    SYSTEM               TEMP                 DEFAULT              NONE
OUTLN                     19/02/04         SYSTEM               TEMP                 DEFAULT              PASSWORD
SYS$UMF                   19/02/04         SYSTEM               TEMP                 DEFAULT              PASSWORD
DBSNMP                    19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
APPQOSSYS                 19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
DBSFWUSER                 19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
GGSYS                     19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
ANONYMOUS                 19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
CTXSYS                    22/03/14         SYSAUX               TEMP                 DEFAULT              PASSWORD
DVSYS                                      SYSAUX               TEMP                 DEFAULT              NONE
SI_INFORMTN_SCHEMA        19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
DVF                                        SYSAUX               TEMP                 DEFAULT              NONE
GSMADMIN_INTERNAL         19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
ORDPLUGINS                19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
MDSYS                     19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
OLAPSYS                   19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
ORDDATA                   19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
XDB                       19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
WMSYS                     19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
ORDSYS                    19/02/04         SYSAUX               TEMP                 DEFAULT              PASSWORD
GSMCATUSER                19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
MDDATA                    19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
SYSBACKUP                 19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
REMOTE_SCHEDULER_AGENT    19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
GSMUSER                   19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
SYSRAC                    19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
AUDSYS                                     USERS                TEMP                 DEFAULT              NONE
DIP                       19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
SYSKM                     19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
ORACLE_OCM                19/02/04         USERS                TEMP                 DEFAULT              PASSWORD
SCOTT                     22/09/10         USERS                TEMP                 DEFAULT              PASSWORD
SYSDG                     19/02/04         USERS                TEMP                 DEFAULT              PASSWORD

36 ���� ���õǾ����ϴ�.