col name for a52
SELECT name
FROM V$CONTROLFILE;