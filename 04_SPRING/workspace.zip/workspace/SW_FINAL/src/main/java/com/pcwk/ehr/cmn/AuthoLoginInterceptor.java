/**
* <pre>
* com.pcwk.ehr.cmn
* Class Name : AuthoLoginInterceptor.java
* Description:
* Author: ITSC
* Since: 2022/07/05
* Version 0.1
* Copyright (C) by KandJang All right
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2022/07/05 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr.cmn;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.interceptor.AsyncExecutionInterceptor;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * @author ITSC
 *
 */

@SuppressWarnings("deprecation")
public class AuthoLoginInterceptor extends HandlerInterceptorAdapter {
	final Logger LOG = LogManager.getLogger(getClass());

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		LOG.debug("----------------------------");
		LOG.debug("-1.preHandle----------------");
		LOG.debug("----------------------------");
		// session 객체를 가져옴
		HttpSession session = request.getSession();
		// login처리를 담당하는 사용자 정보를 담고 있는 객체를 가져옴
		Object obj = session.getAttribute("user");

		if (obj == null) {
			// 로그인이 안되어 있는 상태임으로 로그인 폼으로 다시 돌려보냄(redirect)
			response.sendRedirect(request.getContextPath() + "/login/loginView.do");
			return false; // 더이상 컨트롤러 요청으로 가지 않도록 false로 반환함
		}

		// preHandle의 return은 컨트롤러 요청 uri로 가도 되냐 안되냐를 허가하는 의미임
		// 따라서 true로하면 컨트롤러 uri로 가게됨
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		LOG.debug("----------------------------");
		LOG.debug("2.postHandle----------------");
		LOG.debug("----------------------------");
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		LOG.debug("----------------------------");
		LOG.debug("3.afterCompletion----------------");
		LOG.debug("----------------------------");
		super.afterCompletion(request, response, handler, ex);
	}

}
