/**
* <pre>
* com.pcwk.ehr.login.controller
* Class Name : LonginController.java
* Description:
* Author: ITSC
* Since: 2022/06/23
* Version 0.1
* Copyright (C) by KandJang All right
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2022/06/23 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr.login.controller;

import java.sql.SQLException;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.google.gson.Gson;
import com.pcwk.ehr.cmn.MessageVO;
import com.pcwk.ehr.user.domain.UserVO;
import com.pcwk.ehr.user.service.UserService;

/**
 * @author ITSC
 *
 */
@Controller("longinController")
@RequestMapping("login")
public class LoginController {

	final Logger LOG = LogManager.getLogger(getClass());
	
	@Autowired
	UserService  userService;
	
	@Autowired
	MessageSource  messageSource;
	
	@Autowired
	SessionLocaleResolver localeResolver;
	
	public LoginController() {
		LOG.debug("===========================");
		LOG.debug("=LonginController()=");
		LOG.debug("===========================");
	}
	
	
	@RequestMapping(value="/doLogout.do")
	public String doLogout(HttpSession session)throws SQLException{
		LOG.debug("===========================");
		LOG.debug("=doLogout()=");
		LOG.debug("===========================");		
		
		if(null != session.getAttribute("user")) {
			session.removeAttribute("user");
			session.invalidate();
		}
		
		
		//return "main/main"; board/board_list
		return "login/login"; 
		
	}
	
	
	
	@RequestMapping(value="/doLogin.do"
			, method = RequestMethod.POST 
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String doLogin(UserVO  inVO, HttpSession session, Locale locale)throws SQLException{
		String jsonString = "";
		LOG.debug("===========================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("messageSource:"+messageSource);
		LOG.debug("locale:"+locale);
		LOG.debug("===========================");
		
		
		MessageVO message = userService.idPassCheck(inVO);
        //msgId
		//1. ID확인 : 10
		//2. 비번확인: 20      
		//3. id/비번 통과: 30		
      
		if(null !=message && "30".equals(message.getMsgId())){
			UserVO loginUser = userService.doSelectOne(inVO);
			if(null !=loginUser) {
				session.setAttribute("user", loginUser);
				
				Object[] param = new String[] {loginUser.getName()+"님이  로그인*"};
				String messageStr = messageSource.getMessage("message.msg.confirm", param, locale);
				LOG.debug("messageStr:"+messageStr);
				
				message.setMsgContents(messageStr);
			}
		}
		
		jsonString = new Gson().toJson(message);
		
		LOG.debug("===========================");
		LOG.debug("=jsonString="+jsonString);
		LOG.debug("===========================");		
		return jsonString;
	}
	
	@RequestMapping(value="/localeChange.do", method=RequestMethod.GET)
	public String localeChange(@RequestParam("lang") String language,HttpServletRequest req,Model model)throws SQLException{
		LOG.debug("===========================");
		LOG.debug("=language()="+language);
		LOG.debug("===========================");
		
		Locale locale = Locale.KOREA;
		if("ko".equals(language)) {
			locale = Locale.KOREA;
		}else if("en".equals(language)) {
			locale = Locale.ENGLISH;
		}
		model.addAttribute("lang", language);
		localeResolver.setLocale(req, null, locale);;
		return "login/login";
	}
	
	
	@RequestMapping(value="/loginView.do", method=RequestMethod.GET)
	public String loginView()throws SQLException{
		LOG.debug("===========================");
		LOG.debug("=loginView()=");
		LOG.debug("===========================");
		
		// /WEB-INF/views/login/login.jsp
		return "login/login";
	}
	
	
}
