/**
* <pre>
* com.pcwk.ehr
* Class Name : StringTODateMain.java
* Description:
* Author: ITSC
* Since: 2022/07/05
* Version 0.1
* Copyright (C) by KandJang All right
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2022/07/05 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author ITSC
 *
 */
public class StringTODateMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "1970-01-01 09:00";
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = null;

		try{
			date = format.parse(str);
		}catch(ParseException e){
			
			e.printStackTrace();
		}
		System.out.println("date:"+date);

	}

}
