package studyhtml5;

import org.apache.log4j.Logger;


public class Hello {
    final static Logger LOG = Logger.getLogger(Hello.class);
	public static void main(String[] args) {
		LOG.debug("========================");
		LOG.debug("==\"Hello\"=");
		LOG.debug("========================");
		

	}

}
