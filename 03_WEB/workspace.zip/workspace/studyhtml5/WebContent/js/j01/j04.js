//prompt('오늘 날짜를 입력 하세요.','99');
//alert('자바스크립트');
//document.write('javascript');
//console.log('javascript');
//confirm('저장 하시겠습니까?');   
//var par = document.createElement("p");
//par.append("Hello");
//document.body.append(par);   

console.log(text); // (선언 + 초기화 된 상태)
text = 'Hanamon!'; // (선언 + 초기화 + 할당 된 상태)
var text;
console.log(text);