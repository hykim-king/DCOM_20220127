/**
 * 1.하나의 실행문 끝나면 마지막에 (;)을 붙여 준다. 
 
 */

var num = 5;
document.write(num+"<br/>");    

console.log('num='+num);

// 2. 대소문자를 구분한다.
document.writeln('num='+num);

//document.writeln('NUM='+NUM);

// 3. 주석
//한줄 주석
/*여러줄 주석 */