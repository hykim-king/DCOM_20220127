'use strict';
/*
for ... in                  
    배열의 인덱스를 반환             

*/

let city = ['미국','영국','필리핀','아이슬란드'];

for (let i in city){
    console.log(`i: ${i}, city[${i}]: ${city[i]}`);
}
/*
i: 0, city[0]: 미국
j02.js:11 i: 1, city[1]: 영국
j02.js:11 i: 2, city[2]: 필리핀
j02.js:11 i: 3, city[3]: 아이슬란드
*/

/*
  for ... of문
   향상된 for문
*/
for( let i of city){
    console.log(`i: ${i}`);
}

/*
i: 미국
j02.js:25 i: 영국
j02.js:25 i: 필리핀
j02.js:25 i: 아이슬란드
*/










 