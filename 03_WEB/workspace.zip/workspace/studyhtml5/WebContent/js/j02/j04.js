 
 'use strict';
 
 let infinity = 10/0;
 
 //Infinity
 console.log(`infinity:${infinity}`);
 
 //negativeInfinity:-Infinity
 let negativeInfinity = -10/0;
 console.log(`negativeInfinity:${negativeInfinity}`);
 
 //NaN
 let nAn = "not a number"/10;
 console.log(`nAn: ${nAn}`);