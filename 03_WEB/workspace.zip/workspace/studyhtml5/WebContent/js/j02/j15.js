'use strict';
 
 let num01 = 0;
 let num02 = -11;
 
 //양수 음수 판단.
 console.log(num01>0 ?'양수': '음수');//양수
 console.log(num02>0 ?'양수': '음수');//음수