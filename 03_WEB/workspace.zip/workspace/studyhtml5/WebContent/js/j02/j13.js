'use strict';

//비교 연산자
console.log(`5<2     = ${5<2}`);
console.log(`5==5    = ${5==5}`);
console.log(`5=='5'  = ${5=='5'}`); //5=='5' = true
console.log(`5==='5' = ${5==='5'}`);//5==='5' = false
console.log(`5!=='5' = ${5!=='5'}`);//5!=='5' = true