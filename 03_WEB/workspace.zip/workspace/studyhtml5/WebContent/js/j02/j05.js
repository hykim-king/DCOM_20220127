 'use strict';
 
 let  num01 = 11;
 let  num02 = 13.4;
 let  num03 = 1e+2;//1 * 10에 2승
 console.log(`num01:${num01}, type:${typeof num01}`);
 console.log(`num02:${num02}, type:${typeof num02}`);
 console.log(`num03:${num03}, type:${typeof num03}`);