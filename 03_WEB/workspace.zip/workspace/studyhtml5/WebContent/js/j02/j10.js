//'use strict';
/* 산술연산자: +, -, *, /(몫),%(나머지),++,--,**(exponent)                    */

let num01 = 11;
let num02 = 13;

//num01 + num02 = 24
console.log(`num01 + num02 = ${num01+num02}`);

//num01 - num02 = -2
console.log(`num01 - num02 = ${num01-num02}`);
            
//num01 / num02 = 0.8461538461538461
console.log(`num01 / num02 = ${num01/num02}`);

//num01 % num02 = 11
console.log(`num01 % num02 = ${num01%num02}`);

 num01 = 2;
 num02 = 3;    
 //num01 ** num02 = 8: 2의 3승
//console.log(`num01 ** num02 = ${num01**num02}`); 