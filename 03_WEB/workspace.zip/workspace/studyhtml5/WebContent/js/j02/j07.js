'use strict';
/*
\n              행 바꿈                                                
\t              탭 문자                                                
\\              역슬러시                                                
\'              작은따옴표                                               
\"              큰타옴표                                                
*/
let str01 = "you \'re too smart. ";
let str02 = "자바스크립트 \n jquery ";
let str03 = "자바스크립트 \t jquery ";

console.log(`str01:${str01}`);
console.log(`str02:${str02}`);
console.log(`str03:${str03}`);
 