'use strict';
let sum = 0;
for(let i=1;i<=10;i++){
    console.log(`i:${i}`);
    sum+=i;
}
 
console.log(`sum:${sum}`); 