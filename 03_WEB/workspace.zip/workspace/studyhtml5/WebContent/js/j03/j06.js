'use strict';

let i = 5;
while(i>0){
    
    console.log(`while:${i}`);
    i--;
}
 
 /*
 while:5
j06.js:6 while:4
j06.js:6 while:3
j06.js:6 while:2
j06.js:6 while:1
*/